#include <stdio.h> 

#include "jogo.h"
#include "codemaker.h"
#include "codebreaker.h"


struct JOGO _jogo;

void  cria_jogo_Mastermind(int nslots, int ncolors, int ntries){
  _jogo.nslots = nslots;
  _jogo.ncolors = ncolors;
  _jogo.ntries = ntries;

  cria_CodeMaker(nslots, ncolors);
  cria_CodeBreaker(nslots, ncolors);
  printf("Jogo Iniciado\n");
  
}

int joga_Mastermind() {
  /*    Runs the game for the specified number of tries.
        Returns True if the CodeBreaker guessed the code within the given tries,
        otherwise returns False
  */
  int rodada = 1;

  int* feedback = malloc (sizeof(int) * _jogo.nslots);
  for(int j = 0; j < _jogo.nslots; j++) {
    feedback[j] = 0;
  }

  int* guess = malloc (sizeof(int) * _jogo.nslots);

  for( int i=0; i <  _jogo.ntries; i++, rodada++ ) {
    printf("\nRodada %d\n", rodada);
    run_solver();
    guess = chute (i, _jogo.nslots, feedback, guess);
    printGuess( guess, _jogo.nslots );
    printf("Numero de chutes: %d\n", rodada);
    feedback = codemaker_feedback(guess);
    if( convert_feedback(feedback) )
      return CodeBreaker;
  }

  return CodeMaker;
}

