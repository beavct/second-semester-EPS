#!/bin/bash

#$1 = quantidade de espacos, $2 = quantidade de cores e $3 = numero de tentativas
SOMA=0

for i in  $( seq 1 10 ); do

let SOMA=$(./mastermind $1 $2 $3 | tail -n 2 | head -n 1 | awk '{printf $4}')+${SOMA}

DEZ=${DEZ}-1
done

MEDIA=$(echo "${SOMA}/10 " | bc -l | awk '{printf "%.5s", $1}')
echo media: ${MEDIA}

exit 0