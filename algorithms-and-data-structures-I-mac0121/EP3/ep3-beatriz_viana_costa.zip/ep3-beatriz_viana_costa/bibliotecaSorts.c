#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bibliotecaSorts.h"

void imprimePalavras(int n, palavras *p) {
    int i;

    for (i = 0; i < n; i++) {
        printf ("%s\n", p->palavra[i]);
    }
}

void limpa (palavras *p) {
    free(p->palavra);
    free(p);
}

palavras *lePalavras (int n) {
    int i, lixo;
    palavras *p = malloc (sizeof(palavras));
    p->palavra = calloc (n, sizeof(palavra) * n);
    
    for (i = 0; i < n; i++) 
        lixo = scanf ("%s", p->palavra[i]);
    (void)lixo;
    return p;
}