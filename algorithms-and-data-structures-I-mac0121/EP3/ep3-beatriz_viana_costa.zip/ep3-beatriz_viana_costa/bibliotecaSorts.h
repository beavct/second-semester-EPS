typedef char palavra[11];

typedef struct {
    palavra *palavra;
} palavras;
