#include "arv.h"

no * insercao (no * raiz, char * chave, int linha);
info * resizeInfo(info * velho, int linha);